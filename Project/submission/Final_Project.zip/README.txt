# Bitcoin Price Scraper

## Installing

Install `selenium` 
	$ pip install selenium

Download PhantomJS from the website
	http://phantomjs.org/download.html

## Running

Change the path of PhantomJS in the `scraper.py` file to where it is located

Run the `Three Plots.ipynb` file



